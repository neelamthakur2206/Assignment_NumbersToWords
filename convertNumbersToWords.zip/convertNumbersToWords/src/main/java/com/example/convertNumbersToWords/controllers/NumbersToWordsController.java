package com.example.convertNumbersToWords.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.convertNumbersToWords.exceptionHandler.NotANumberException;
import com.example.convertNumbersToWords.exceptionHandler.NotValidNumberException;
import com.example.convertNumbersToWords.models.ServiceResponse;
import com.example.convertNumbersToWords.services.NumbersToWordsServicesImpl;

@RestController
@RequestMapping("/numbersToWords")
public class NumbersToWordsController {
	
	@Autowired
	private NumbersToWordsServicesImpl numbersToWordsServices;

	@GetMapping(path="/{number}", produces = "application/json")
    public ResponseEntity<ServiceResponse> convertNumbersToWords(@PathVariable(value = "number") String number) throws Exception {
    	
		int length = String.valueOf(number).length();
		boolean isNumeric = number.chars().allMatch( Character::isDigit );
		
		if(!isNumeric) {
			throw new NotANumberException(number);
		}
		
		if(length > 9) {
			throw new NotValidNumberException(number);
		}
		
		//Hard coding the "BRITISH_ENGLISH" parameter currently. We can accepted this parameter from  the URL as well. 
        String words = numbersToWordsServices.convertNumberToWord(Long.parseLong(number), "BRITISH_ENGLISH");        
        ServiceResponse response = new ServiceResponse(HttpStatus.OK,HttpStatus.OK.value(),number,words);
    	
        return new ResponseEntity<ServiceResponse>(response, HttpStatus.OK);
    }
}
