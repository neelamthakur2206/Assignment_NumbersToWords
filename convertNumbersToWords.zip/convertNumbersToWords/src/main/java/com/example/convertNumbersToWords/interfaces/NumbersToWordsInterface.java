package com.example.convertNumbersToWords.interfaces;

public interface NumbersToWordsInterface {

	String convertNumberToWord(Long number);
}
