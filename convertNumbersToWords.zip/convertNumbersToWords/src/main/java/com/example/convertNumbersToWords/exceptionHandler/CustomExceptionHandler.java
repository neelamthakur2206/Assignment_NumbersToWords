package com.example.convertNumbersToWords.exceptionHandler;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.example.convertNumbersToWords.models.ErrorResponse;

@SuppressWarnings({"unchecked","rawtypes"})
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler
{
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        ErrorResponse error = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR,HttpStatus.INTERNAL_SERVER_ERROR.value(), "Server Error", details.toString());
        return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(NotValidNumberException.class)
    protected ResponseEntity<Object> handleBadRequest(HttpServletRequest req, Exception ex) {
        
        ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST,HttpStatus.BAD_REQUEST.value(), "Validation Failed", "Enter a valid Number between 1 to 999999999");
        return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
    } 
    
    @ExceptionHandler(NotANumberException.class)
    protected ResponseEntity<Object> notANumber(HttpServletRequest req, Exception ex) {
        
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_ACCEPTABLE,HttpStatus.NOT_ACCEPTABLE.value() , "Validation Failed", "Enter a valid Number between 1 to 999999999");
        return new ResponseEntity(error, HttpStatus.NOT_ACCEPTABLE );
    } 
}