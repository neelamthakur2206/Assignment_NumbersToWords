package com.example.convertNumbersToWords.exceptionHandler;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Enter Valid Number Between 1 to 999999999")  // 404
public class NotValidNumberException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String number;

	public NotValidNumberException() {
		
	}
	
	public NotValidNumberException(String number) {
		super();
		this.number = number;
	}
	
}
