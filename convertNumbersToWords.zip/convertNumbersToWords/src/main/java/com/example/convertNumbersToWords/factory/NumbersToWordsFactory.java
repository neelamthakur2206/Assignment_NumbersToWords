package com.example.convertNumbersToWords.factory;

import org.springframework.stereotype.Component;

import com.example.convertNumbersToWords.implementations.NumbersToAmericanEnglishWords;
import com.example.convertNumbersToWords.implementations.NumbersToBritishEnglishWords;
import com.example.convertNumbersToWords.interfaces.NumbersToWordsInterface;

@Component
public class NumbersToWordsFactory {

	private static NumbersToWordsInterface single_instance;	

	public static NumbersToWordsInterface getInstance(String wordType) {
		
		 if (wordType == "BRITISH_ENGLISH") { 
			 single_instance = new NumbersToBritishEnglishWords(); 
		 }
		 else if(wordType == "AMERICAN_ENGLISH"){
			 single_instance = new NumbersToAmericanEnglishWords();
		 }
	     return single_instance; 
	}
	
}
