package com.example.convertNumbersToWords;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.convertNumbersToWords.models.ServiceResponse;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class ConvertNumbersToWordsApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;
	
	@LocalServerPort
	private int port;
	
	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {
	}

	@Test
	public void checkSuccessStatusCode() {			
		ResponseEntity<ServiceResponse> res = restTemplate.getForEntity(getRootUrl() + "/numbersToWords/56945781", ServiceResponse.class);
		System.out.println(res.getStatusCodeValue());
		Assert.assertEquals(HttpStatus.OK.value(), res.getStatusCodeValue());
	}

	@Test
	public void checkMinNumberRange() {			
		ResponseEntity<ServiceResponse> res = restTemplate.getForEntity(getRootUrl() + "/numbersToWords/0", ServiceResponse.class);
		System.out.println(res.getStatusCodeValue());
		Assert.assertEquals(HttpStatus.OK.value(), res.getStatusCodeValue());
	}
	
	@Test
	public void checkTheMaxNumberRange() {			
		ResponseEntity<ServiceResponse> res = restTemplate.getForEntity(getRootUrl() + "/numbersToWords/999999999999", ServiceResponse.class);
		System.out.println(res.getStatusCodeValue());
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
	}
	
	@Test
	public void checkIfParamIsNumeric() {	
		ResponseEntity<ServiceResponse> res = restTemplate.getForEntity(getRootUrl() + "/numbersToWords/one", ServiceResponse.class);
		System.out.println(res.getStatusCodeValue());
		Assert.assertEquals(HttpStatus.NOT_ACCEPTABLE.value(), res.getStatusCodeValue());
	}

}
